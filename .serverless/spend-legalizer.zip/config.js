var configs = {};
configs.applicationPort = process.env.PORT || 8000;
configs.dbHost = "localhost";

module.exports = configs;
