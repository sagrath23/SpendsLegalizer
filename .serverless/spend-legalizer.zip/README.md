# SpLegalizer

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/b685a18756964cce9b50ebbc527df2ae)](https://www.codacy.com/app/sagrath23/SpendsLegalizer?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=sagrath23/SpendsLegalizer&amp;utm_campaign=Badge_Grade)
[![Build Status](https://travis-ci.org/sagrath23/SpendsLegalizer.svg?branch=master)](https://travis-ci.org/sagrath23/SpendsLegalizer)
[![Codacy Badge](https://api.codacy.com/project/badge/Coverage/b685a18756964cce9b50ebbc527df2ae)](https://www.codacy.com/app/sagrath23/SpendsLegalizer?utm_source=github.com&utm_medium=referral&utm_content=sagrath23/SpendsLegalizer&utm_campaign=Badge_Coverage)


Express & ES6 REST API Boilerplate

This is a straightforward boilerplate for building REST APIs with ES6 and Express.
