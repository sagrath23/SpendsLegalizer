var helpers = {};

helpers.test = function() {
    return true;
};

helpers.anotherTest = function() {
    return false;
};

module.exports = helpers;
